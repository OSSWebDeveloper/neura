
function foo(){
    console.log("lalula")
}